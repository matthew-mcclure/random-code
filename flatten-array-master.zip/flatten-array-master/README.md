# flatten-array
A few examples of ways to flatten arrays in JavaScript
